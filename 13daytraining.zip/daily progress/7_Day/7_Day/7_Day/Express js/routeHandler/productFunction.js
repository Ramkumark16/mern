const fs = require("fs");
const path = require("path");
const productData = JSON.parse(fs.readFileSync(path.join(__dirname, '../','./model/product.json'), 'utf-8'));

let productStorage = []; // Temporary storage. In a real app, you'd use a database

const fetchAllProducts = (req, res) => {
    res.status(200).json({
        status: 'success',
        results: productStorage.length,
        data: {
            products: productData
        }
    });
};

const fetchProductById = (req, res) => {
    const productId = parseInt(req.params.id);
    const product = productData.find((p) => p.id === productId);

    if (!product) {
        return res.status(404).json({
            status: 'fail',
            message: 'Product not found'
        });
    }

    res.status(200).json({
        status: 'success',
        data: {
            product
        }
    });
};

const addProduct = (req, res) => {
    if (!req.body.name || !req.body.count) {
        return res.status(400).json({
            status: 'fail',
            message: 'Name and count are required fields'
        });
    }

    const newProduct = {
        id: productData.length + 1,
        name: req.body.name,
        count: req.body.count
    };
    
    try {
        productData.push(newProduct);

        fs.writeFileSync(
            path.join(__dirname, '../', './model/product.json'),
            JSON.stringify(productData, null, 4),
            'utf-8'
        );
        
        res.status(201).json({
            status: 'success',
            data: {
                product: newProduct
            }
        });
    } catch (error) {
        res.status(500).json({
            status: 'error',
            message: 'Error saving product'
        });
    }
};

const removeProduct = (req, res) => {
    const productId = parseInt(req.params.id);
    const productIndex = productStorage.findIndex(p => p.id === productId);

    if (productIndex === -1) {
        return res.status(404).json({
            status: 'fail',
            message: 'Product not found'
        });
    }

    productStorage.splice(productIndex, 1);
    
    res.status(204).json({
        status: 'success',
        data: null
    });
};

const updateProductPartial = (req, res) => {
    const productId = parseInt(req.params.id);
    const productIndex = productStorage.findIndex(p => p.id === productId);

    if (productIndex === -1) {
        return res.status(404).json({
            status: 'fail',
            message: 'Product not found'
        });
    }

    productStorage[productIndex] = { ...productStorage[productIndex], ...req.body };
    
    res.status(200).json({
        status: 'success',
        data: {
            product: productStorage[productIndex]
        }
    });
};

const updateProduct = (req, res) => {
    const productId = parseInt(req.params.id);
    const productIndex = productStorage.findIndex(p => p.id === productId);

    if (productIndex === -1) {
        return res.status(404).json({
            status: 'fail',
            message: 'Product not found'
        });
    }

    productStorage[productIndex] = { id: productId, ...req.body };
    
    res.status(200).json({
        status: 'success',
        data: {
            product: productStorage[productIndex]
        }
    });
};

const validateProductData = (request, response, next) => {
    const requestBody = request.body;
    const requestHeaders = request.headers;
    console.log(requestHeaders);
    
    if(!requestBody.name || !requestBody.count){
        return response.status(400).json({
            status: "fail",
            message: "Name and count are required fields"
        });
    }
    next();
};

const validateProductId = (req, res, next, id) => {
    id = parseInt(id);
    const product = productData.find((p) => p.id === id);
    if(!product){
        return res.status(400).json({
            status: "fail",
            message: "Product not found"
        });
    }
    next();
};

module.exports = {
    fetchAllProducts,
    fetchProductById,
    addProduct,
    removeProduct,
    updateProductPartial,
    updateProduct,
    validateProductData,
    validateProductId
};

// bcrypt
