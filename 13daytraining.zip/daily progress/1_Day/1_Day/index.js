// FORWARD PRINTING USING FOR LOOP
document.write("<pre>");
document.write("FOR LOOP Forward Printing\n");
for (let i = 0; i < 3; i++) {
    document.write(i + "\t");
}
document.write("</pre>");

console.log("FOR LOOP Forward Printing");
for (let i = 0; i < 3; i++) {
    console.log(i);
}

// REVERSE PRINTING USING FOR LOOP
document.write("<pre>");
document.write("FOR LOOP Reverse Printing\n");
for (let i = 3; i > 0; i--) {
    document.write(i + "\t");
}
document.write("</pre>");

console.log("FOR LOOP Reverse Printing");
for (let i = 3; i > 0; i--) {
    console.log(i);
}

// FORWARD PRINTING USING WHILE LOOP
console.log("While Loop Forward Printing");
let j = 0;
while (j < 3) {
    console.log(j);
    j++;
}

// REVERSE PRINTING USING WHILE LOOP
console.log("While Loop Reverse Printing");
let k = 3;
while (k > 0) {
    console.log(k);
    k--;
}

// isNaN FUNCTION
console.log("isNaN Function");
console.log(!isNaN(12));

// FUNCTION DECLARATION
function sayHello() {
    console.log("Calling a Function");
}
sayHello();

// ARROW FUNCTION FOR ADDITION
const addTwoNumbers = (a, b) => a + b;
console.log("Two value Addition Function: ", addTwoNumbers(3, 8));

// ARROW FUNCTION FOR METHOD OVERLOADING (ADDING THREE NUMBERS)
const addThreeNumbers = (a, b, c) => a + b + c;
console.log("Three value Addition Function: ", addThreeNumbers(3, 4, 2));

// FUNCTION FOR ADDING FOUR NUMBERS
function addFourNumbers(val1, val2, val3, val4) {
    return val1 + val2 + val3 + val4;
}
console.log("Four value Addition Function: ", addFourNumbers(3, 4, 2, 4));

// FUNCTION TO SUM ARRAY ELEMENTS
const sumArrayElements = (myArray) => {
    return myArray.reduce((sum, i) => sum + i, 0);
};
console.log("Sum of Array Elements: ", sumArrayElements([2, 3, 4, 2, 1]));

// ARRAY METHODS
const numbers = [2, 3, 4, 5, 3];

console.log("Map Function");
const incrementedNumbers = numbers.map(i => i + 1);
console.log(incrementedNumbers);
console.log("Original Array: ", numbers);

console.log("Filter Function");
const filteredNumbers = numbers.filter(i => i < 4);
console.log(filteredNumbers);

console.log("Some Function");
const hasNumberLessThanFive = numbers.some(i => i < 5);
console.log(hasNumberLessThanFive);

// OBJECT EXAMPLE
const testObj = { name: "John", age: 23 };
console.log(testObj.name, testObj.age);

// SPREAD OPERATOR
const newArray = [...numbers, 6, 7];
console.log("Spread Operator: ", newArray);

// REST OPERATOR
function sumUsingRest(...values) {
    return values.reduce((sum, i) => sum + i, 0);
}
console.log("Rest Function: ", sumUsingRest(...numbers));