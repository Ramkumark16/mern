localStorage.setItem("getBack", 250);
console.log(localStorage.getItem("getBack"));

let reloadCount = Number(localStorage.getItem("reload")) || 0;
localStorage.setItem("reload", ++reloadCount);
console.log(reloadCount);

localStorage.setItem("username", "JohnDoe");
console.log("Username:", localStorage.getItem("username"));

localStorage.setItem("username", "JaneDoe");
console.log("Updated Username:", localStorage.getItem("username"));

localStorage.removeItem("username");
console.log("Username after removal:", localStorage.getItem("username"));