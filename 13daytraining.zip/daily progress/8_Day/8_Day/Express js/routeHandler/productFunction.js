const fs = require("fs");
const path = require("path");
const jsonData = JSON.parse(fs.readFileSync(path.join(__dirname, '../', './model/product.json'), 'utf-8'));

let products = []; // Temporary storage. Use a database in production.

// Get all products
const getAll = (req, res) => {
    res.status(200).json({
        status: 'success',
        message: 'All products retrieved successfully.',
        results: products.length,
        data: {
            products: jsonData
        }
    });
};

// Get a single product by ID
const getOne = (req, res) => {
    const id = parseInt(req.params.id);
    const product = jsonData.find((p) => p.id === id);

    if (!product) {
        return res.status(404).json({
            status: 'fail',
            message: `Product with ID ${id} not found. Please check the ID and try again.`
        });
    }

    res.status(200).json({
        status: 'success',
        message: `Product with ID ${id} retrieved successfully.`,
        data: {
            product
        }
    });
};

// Add a new product
const post = (req, res) => {
    if (!req.body.name || !req.body.count) {
        return res.status(400).json({
            status: 'fail',
            message: 'Both "name" and "count" are required to add a product.'
        });
    }

    const newProduct = {
        id: jsonData.length + 1,
        name: req.body.name,
        count: req.body.count
    };
    
    try {
        jsonData.push(newProduct);

        fs.writeFileSync(
            path.join(__dirname, '../', './model/product.json'),
            JSON.stringify(jsonData, null, 4),
            'utf-8'
        );

        res.status(201).json({
            status: 'success',
            message: 'Product added successfully.',
            data: {
                product: newProduct
            }
        });
    } catch (error) {
        res.status(500).json({
            status: 'error',
            message: 'An error occurred while saving the product. Please try again later.'
        });
    }
};

// Delete a product by ID
const deleteOne = (req, res) => {
    const id = parseInt(req.params.id);
    const productIndex = products.findIndex(p => p.id === id);

    if (productIndex === -1) {
        return res.status(404).json({
            status: 'fail',
            message: `Product with ID ${id} not found. Unable to delete.`
        });
    }

    products.splice(productIndex, 1);

    res.status(204).json({
        status: 'success',
        message: `Product with ID ${id} deleted successfully.`,
        data: null
    });
};

// Update product partially (PATCH)
const patch = (req, res) => {
    const id = parseInt(req.params.id);
    const productIndex = products.findIndex(p => p.id === id);

    if (productIndex === -1) {
        return res.status(404).json({
            status: 'fail',
            message: `Product with ID ${id} not found. Unable to update.`
        });
    }

    products[productIndex] = { ...products[productIndex], ...req.body };

    res.status(200).json({
        status: 'success',
        message: `Product with ID ${id} updated successfully.`,
        data: {
            product: products[productIndex]
        }
    });
};

// Replace a product (PUT)
const put = (req, res) => {
    const id = parseInt(req.params.id);
    const productIndex = products.findIndex(p => p.id === id);

    if (productIndex === -1) {
        return res.status(404).json({
            status: 'fail',
            message: `Product with ID ${id} not found. Unable to replace.`
        });
    }

    products[productIndex] = { id, ...req.body };

    res.status(200).json({
        status: 'success',
        message: `Product with ID ${id} replaced successfully.`,
        data: {
            product: products[productIndex]
        }
    });
};

// Middleware to validate request body
const validator = (request, response, next) => {
    let body = request.body;
    let header = request.headers;
    console.log("Request headers:", header);

    if (!body.name || !body.count) {
        return response.status(400).json({
            status: "fail",
            message: 'Both "name" and "count" are required fields.'
        });
    }
    next();
};

// Middleware to validate product ID
const idValidator = (req, res, next, id) => {
    id *= 1;
    const item = jsonData.find((p) => p.id === id);
    if (!item) {
        return res.status(400).json({
            status: "fail",
            message: `Invalid ID: Product with ID ${id} does not exist.`
        });
    }
    next();
};

module.exports = {
    getAll,
    getOne,
    post,
    deleteOne,
    patch,
    put,
    validator,
    idValidator
};
