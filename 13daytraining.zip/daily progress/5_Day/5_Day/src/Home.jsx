function Home() {
  return (
    <div className="flex justify-center items-center animate-spin min-h-screen">
      <div className="rounded-lg bg-yellow-500 text-black p-4 max-w-sm">
        <div className="bg-red-500 w-full p-2 text-center hover:scale-105 transition-transform duration-300 mb-2">
          Red Container
        </div>
        <div className="bg-blue-500 w-full p-2 text-center hover:scale-105 transition-transform duration-300 mb-2">
          Blue Container
        </div>
        <div className="bg-black w-full p-2 text-center text-white hover:scale-105 transition-transform duration-300 mb-2">
          Black Container
        </div>
        <div className="bg-gray-500 w-full p-2 text-center hover:scale-105 transition-transform duration-300 mb-2">
          Gray Container
        </div>
        <div className="bg-yellow-500 w-full p-2 text-center hover:scale-105 transition-transform duration-300">
          Yellow Container
        </div>
      </div>
    </div>
  );
}

export default Home;
