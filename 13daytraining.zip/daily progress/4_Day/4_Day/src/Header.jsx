const Header = () => {
    return (
        <button id='button'>Click Me</button>
    )
}
export default Header;