function Content() {
  return (
    <>
      <div className="flex justify-center items-center min-h-screen bg-gray-100">
        <div className="text-center p-6 rounded-lg bg-white shadow-lg">
          <h1 className="text-2xl font-bold mb-4">Welcome to the Content Page</h1>
        </div>
      </div>
    </>
  );
}

export default Content;
